﻿using EmployeeAPI.Interfaces;
using EmployeeAPI.Model;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeAPI.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : Controller
    {
        readonly IEmployee _Iemp;
        public EmployeeController(IEmployee Iemp)
        {
            _Iemp = Iemp;
        }
        [HttpGet]
        [ProducesResponseType(200, Type = typeof(IEnumerable<Employee>))]
        public IActionResult GetEmployees()
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var employees = _Iemp.listOfEmployees();
            return (IActionResult)employees;
        }

        [HttpGet("{EmloyeeID}")]
        [ProducesResponseType(200, Type = typeof(Employee))]
        public IActionResult GetEmployee(int id)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var student = _Iemp.GetEmployee(id);
            return (IActionResult)student;
        }
        [HttpPut("employeeid")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        public IActionResult updateEmployee(int id,[FromBody] Employee emp)
        {
           
            if (emp == null)
                return BadRequest(ModelState);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            if (emp.FirstName == null && emp.LastName == null && emp.Salary == 0)
            {
                ModelState.AddModelError(" ", "These fields must be filled");
                return StatusCode(500, ModelState);
            }
            if (_Iemp.emloyeeExist(emp.EmployeeID))
                return NotFound();
            var employee = _Iemp.GetEmployee(id);
            if (!_Iemp.updateEmployee(employee))
            {
                ModelState.AddModelError(" ", "Error in saving");
                return StatusCode(500, ModelState);
            }
            return NoContent();
        }
        [HttpPost]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        public IActionResult createEmployee([FromBody] Employee emp)
        {
            if (emp == null)
                return BadRequest(ModelState);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            if (emp.FirstName == null && emp.LastName == null && emp.Salary == 0)
            {
                ModelState.AddModelError(" ", "These fields must be filled");
                return StatusCode(500, ModelState);
            }
            if (!_Iemp.createEmployee(emp))
            {
                ModelState.AddModelError(" ", "Error in saving");
                return StatusCode(500, ModelState);
            }
            return NoContent();
        }
    }
}

﻿using EmployeeAPI.Data;
using EmployeeAPI.Interfaces;
using EmployeeAPI.Model;

namespace EmployeeAPI.Repostries
{
    public class EmployeeRepostry : IEmployee
    {
        readonly DataContext _context;
        public EmployeeRepostry(DataContext context)
        {
            _context = context;
        }

        public bool createEmployee(Employee emp)
        {
            _context.Add(emp);
            return save();
        }

        public bool emloyeeExist(int id)
        {
            return _context.employees.Any(p => p.EmployeeID == id);
        }

        public Employee GetEmployee(int id)
        {
            return _context.employees.Where(p => p.EmployeeID == id).FirstOrDefault();
        }

        public ICollection<Employee> listOfEmployees()
        {
            return _context.employees.OrderBy(p => p.EmployeeID).ToList();
        }

        public bool save()
        {
            var saved = _context.SaveChanges();
            return saved > 0 ? true : false;
        }

        public bool updateEmployee(Employee emp)
        {
            _context.Update(emp);
            return save();
        }


    }
}

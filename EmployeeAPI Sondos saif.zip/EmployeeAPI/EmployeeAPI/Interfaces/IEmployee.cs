﻿using EmployeeAPI.Model;

namespace EmployeeAPI.Interfaces
{
    public interface IEmployee
    {
        bool createEmployee(Employee emp);
        bool updateEmployee(Employee emp);
        ICollection<Employee> listOfEmployees();
        Employee GetEmployee(int id);
        bool save();
        bool emloyeeExist(int id);
    }
}
